package com.example.myapplication2

import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Instantiate the RequestQueue.
        val queue = Volley.newRequestQueue(this)
        val url = "https://catfact.ninja/fact"
        val textView = findViewById<TextView>(R.id.fact11)
        val button = findViewById<TextView>(R.id.btnrefresh)

        val stringRequest = StringRequest(
            Request.Method.GET, url,
            Response.Listener<String> { response ->
                // Display the first 500 characters of the response string.
                val obj = JSONObject(response)
                Log.d("MyApp", obj.toString())
                textView.text = obj.getString("fact");
            },
            Response.ErrorListener {
                textView.text = "That didn't work!"
            })
        queue.add(stringRequest)
        button.setOnClickListener {
            val stringRequest = StringRequest(
                Request.Method.GET, url,
                Response.Listener<String> { response ->
                    // Display the first 500 characters of the response string.
                    val obj = JSONObject(response)
                    Log.d("MyApp", obj.toString())
                    textView.text = obj.getString("fact");

                },
                Response.ErrorListener {
                    textView.text = "That didn't work!"
                })
            queue.add(stringRequest)
        }


    }

    override fun onBackPressed()
    {
        Log.d("backpressed","backpressed")
        MaterialAlertDialogBuilder(this)
            .setTitle("Alert")
            .setMessage(
                "Are you sure that you want to exit the App?")
            .setPositiveButton("Yes") {
                dialog , which ->
                super.onBackPressed()

            }
            .show()
            }
    }
